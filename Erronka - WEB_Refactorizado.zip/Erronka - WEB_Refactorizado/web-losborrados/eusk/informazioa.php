<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../../../../../public/Argazkiak/phonix.png">
    <script src="https://kit.fontawesome.com/7f605dc8fe.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../../../../css/informazioa.css">
    <title>Informazioa</title>
</head>
<body>
    <div class="oferta">
        <p>¡Oferta!</p>
    </div>
    <a href="https://www.goierrieskola.eus/es/">
        <img class="goierri" src="../../../../../public/Argazkiak/goierri-logo.png" alt="Goierri Logo" href="https://www.goierrieskola.eus/es/">
    </a>

    <!---HEADER-->
    <?php
    require_once(__DIR__ . '/../../../../php/header_eus.php');
    ?>

    <main>
        <article>
            <h2>¡Ongi etorri Reborn-era!</h2>
                <p>
                    Sortzaileak: <br>
                    - Gorka Bartolome <br>
                    - Haimar Arizeta <br>
                    - Eneko Benitez <br>
                    <br><br>
                    Ongi etorri Reborn -ra, ordenagailuak eta produktu informatikoak berregokitzen dituen enpresa berritzaile batera. Etengabeko bilakaera teknologikoa duen mundu honetan, gure helburu nagusi: gailu elektronikoak berpiztea, konponbide eskuragarriak eskaintzea eta industria teknologikoan iraunkortasuna sustatzea da. <br><br>
                    Kalitatearekin, irisgarritasunarekin eta ingurumen-erantzukizunarekin dugun konpromisoaren bidez, teknologiak gure bizitzetan eta planetan nola eragiten duen birdefinitzen ari gara. Bat egin gurekin etorkizun adimentsuago eta iraunkorrago baterako bidaia zirraragarri honetan.
          <br><br>
          Kokapen hau aukeratu dugu Estonia gure enpresarentzat ingurune aproposa delako. Herrialdearen ingurune digital aurreratua eta guztiz digitalizatutako negozioen kudeaketa funtsezkoak dira gure ikuspegi berritzailerako. Europan dagoen kokapen estrategikoak Europako merkatura erraz sartzeko aukera ematen digu, eta horrek gure eragiketak konplikaziorik gabe zabaltzeko aukera emango digu.          
<br><br>
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2029.1327978583063!2d24.751430199999998!3d59.430859700000006!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4692949f7ae44fe5%3A0x8d0a32860b59f9b5!2sKentmanni%2C%20Tallinn%2C%20Estonia!5e0!3m2!1ses!2ses!4v1698934308789!5m2!1ses!2ses" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
</p>			
        </article>
    </main>
   
 
     <!---FOOTER-->
     <?php
     require_once(__DIR__ . '/../../../php/footer_eus.php');
     ?>


</body>
</html>
