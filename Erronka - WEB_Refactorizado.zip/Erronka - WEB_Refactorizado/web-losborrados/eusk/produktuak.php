<!---PRODUKTU-->
<?php
    require_once(__DIR__ . '/../../../../php/produktu_eus.php');
    ?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../../../../../public/Argazkiak/phonix.png">
    <script src="https://kit.fontawesome.com/7f605dc8fe.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../../../../css/produktuak2.css">
    <title>Produktuak</title>
</head>
<body>
    <div class="oferta">
        <p>¡Oferta!</p>
    </div>
    <a href="https://www.goierrieskola.eus/es/">
        <img class="goierri" src="../../../../../public/Argazkiak/goierri-logo.png" alt="Goierri Logo" href="https://www.goierrieskola.eus/es/">
    </a>

    <!---HEADER-->
    <?php
    require_once(__DIR__ . '/../../../../php/header_eus.php');
    ?>
    </header>
    <center>
        <div class="hornitzailea">
            <p><a href="hornitzailea.php">Hornitzaile izan nahi al duzu?</a></p>
        </div>
    </center><br><br>

    <h2>Produktuen taula</h2>

    <form method="GET">
        <label for="marca">Iragazi markaren arabera:</label>
        <select name="marca" id="marca">
            <option value="">Hautatu marka bat</option>
            <?php foreach ($marcas as $marca) : ?>
                <option value="<?php echo $marca; ?>"><?php echo $marca; ?></option>
            <?php endforeach; ?>
        </select>

        <label for="modelo">Iragazi ereduaren arabera:</label>
        <select name="modelo" id="modelo">
            <option value="">Aukeratu eredu bat</option>
            <?php foreach ($modelos as $modelo) : ?>
                <option value="<?php echo $modelo; ?>"><?php echo $modelo; ?></option>
            <?php endforeach; ?>
        </select>

        <label for="precio">Ordenatu prezioaren arabera:</label>
        <select name="precio" id="precio">
            <option value="asc">Prezio merkeagoa</option>
            <option value="desc">Prezio garestiagoa</option>
        </select>

        <input type="submit" value="Iragazkia">
        <input type="submit" name="todos" value="Erakutsi dena">
    </form>
   
   
     <!---PRODUKTU-->
     <?php
    require_once(__DIR__ . '/../../../../php/produktu.php');
    ?>



    
     <!---FOOTER-->
     <?php
    require_once(__DIR__ . '/../../../../php/footer_eus.php');
    ?>

    <?php
    $conn->close();
    ?>
</body>
</html>