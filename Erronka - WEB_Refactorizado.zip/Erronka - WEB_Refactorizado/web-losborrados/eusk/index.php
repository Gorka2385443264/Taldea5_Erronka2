<?php
require_once(__DIR__ . '/../../../php/index.php');
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../../../../public/Argazkiak/phonix.png">
    <script src="https://kit.fontawesome.com/7f605dc8fe.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../../../css/index.css">
    <title>Hasiera</title>
</head>
<body>
    <div class="oferta">
        <p>¡Eskaintzak!</p>
    </div>
    <a href="https://www.goierrieskola.eus/es/">
        <img class="goierri" src="../../../../public/Argazkiak/goierri-logo.png" alt="Goierri Logo" href="https://www.goierrieskola.eus/es/">
    </a>


   

     <!---HEADER-->
     <?php
    require_once(__DIR__ . '/../../../php/header_eus.php');
    ?>

    <br>
    <div class="tituloa">
    <h2>Tendentziak <i class="fa-solid fa-fire"></i></h2>
   <div class="productos">
        <div class="producto_1"><a class="produktuak_esteka" href="#">
            <i class="fa-solid fa-fire"></i>MSI MPG B550 GAMING PLUS 

            <br>
            <img src="../../../../public/Argazkiak/Productos/producto_1.png" alt="">
        </a>
        </div>
        <div class="producto_2">
            <i class="fa-solid fa-fire"></i>WD BLACK SN770 1TB SSD

            <br>
            <img src="../../../../public/Argazkiak/Productos/producto_2.png" alt="">
        </div>
        <div class="producto_3">
            <i class="fa-solid fa-fire"></i>Sapphire Pulse AMD Radeon RX 6700 XT 

            <br>
            <img src="../../../../public/Argazkiak/Productos/producto_3.png" alt="">
        </div>
        <div class="producto_4">
            <i class="fa-solid fa-fire"></i>MSI MAG A650BN 650W 80 Plus Bronze

            <br>
            <img src="../../../../public/Argazkiak/Productos/producto_4.png" alt="">
        </div>
   </div>
    </div>
    <!---LA PARTE DE LAS NEWS DE LA PAGINA-->
    <br>
    <h2>Albisteen Mahaia</h2><br>


    <form method="post">
        <label for="ordenar">Nola ordenatu nahi duzu taula dataren arabera?</label><br>
        <select name="orden">
            <option value="ASC">Berria</option>
            <option value="DESC">Zaharra</option>
        </select>
        <input type="submit" name="ordenar_fecha" value="Dataren arabera ordenatzeko"><br><br>

        <label for="buscar_fecha_vieja">Bilatu data zaharragoak/berdinak:</label><br>
          <input class="input_texto" type="text" name="fecha_ingresada_vieja" placeholder="Data (AAAA-MM-DD)">
    <input type="submit" name="buscar_mas_vieja" value="Bilatu data zaharragoak"><br><br>

    <label for="buscar_fecha_nueva">Bilatu data berriak/berberak:</label><br>
    <input class="input_texto" type="text" name="fecha_ingresada_nueva" placeholder="Data (AAAA-MM-DD)">
    <input type="submit" name="buscar_mas_nueva" value="Bilatu data berriak"><br><br>

        <label for="buscar_entre_fechas">Bilatu bi dateren artean:</label><br>
        <input class="input_texto" type="text" name="fecha_inicial" placeholder="Hasierako data (AAAA-MM-DD)">
        <input class="input_texto" type="text" name="fecha_final" placeholder="Azken eguna (AAAA-MM-DD)">
        <input type="submit" name="buscar_entre_fechas" value="Bilatu bi dateren artean"><br><br>

        <input type="submit" name="ver_todos" value="Dena ikusi">
    </form>

    <?php
if ($result->num_rows > 0) {
    echo '<div class="noticias-container">';
    $counter = 0;

    while ($row = $result->fetch_assoc()) {
        if ($counter % 3 == 0) {
            echo '<div class="noticias-row">';
        }

        echo '<div class="noticias">';
        echo '<div class="imagen-noticia"><img src="' . $row["Imagen"] . '" alt="Imagen del producto"></div>';
        echo '<div class="contenido-noticia">';
        echo '<h2>' . $row["Fecha"] . '</h2>';
        echo '<h3>' . $row["Izenburua"] . '</h3><br>';
        echo '<p class="texto-cortado">' . $row["Textua"] . '</p>';
        echo '</div>'; // Cierre de div para el contenido de la noticia
        echo '</div>'; // Cierre de div para la noticia

        $counter++;

        if ($counter % 3 == 0) {
            echo '</div>'; // Cierre de la fila después de 3 noticias
        }
    }

    echo '</div>'; // Cierre del contenedor principal
} else {
    echo 'No se encontraron las noticias, en las fechas indicadas.';
}
?>






     <!---FOOTER-->
     <?php
    require_once(__DIR__ . '/../../../php/footer_eus.php');
    ?>

    <?php
    $conn->close();
    ?>
</body>
</html>