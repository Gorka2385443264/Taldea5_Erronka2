<!---PRODUKTU-->
<?php
    require_once(__DIR__ . '/../../../../php/produktu_esp.php');
    ?>




<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../../../../../public/Argazkiak/phonix.png">
    <script src="https://kit.fontawesome.com/7f605dc8fe.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../../../../css/produktuak2.css">
    <title>Informacion</title>
</head>
<body>
    <div class="oferta">
        <p>¡Oferta!</p>
    </div>
    <a href="https://www.goierrieskola.eus/es/">
        <img class="goierri" src="../../../../../public/Argazkiak/goierri-logo.png" alt="Goierri Logo" href="https://www.goierrieskola.eus/es/">
    </a>

    <!---HEADER-->
    <?php
    require_once(__DIR__ . '/../../../../php/header_esp.php');
    ?>
    <center>
        <div class="hornitzailea">
            <p><a href="hornitzailea.php">¿Quieres ser un proveedor?</a></p>
        </div>
    </center><br><br>

    <h2>Tabla de Productos</h2>

    <form method="GET">
        <label for="marca">Filtrar por marca:</label>
        <select name="marca" id="marca">
            <option value="">Seleccione una marca</option>
            <?php foreach ($marcas as $marca) : ?>
                <option value="<?php echo $marca; ?>"><?php echo $marca; ?></option>
            <?php endforeach; ?>
        </select>

        <label for="modelo">Filtrar por modelo:</label>
        <select name="modelo" id="modelo">
            <option value="">Seleccione un modelo</option>
            <?php foreach ($modelos as $modelo) : ?>
                <option value="<?php echo $modelo; ?>"><?php echo $modelo; ?></option>
            <?php endforeach; ?>
        </select>

        <label for="precio">Ordenar por precio:</label>
        <select name="precio" id="precio">
            <option value="asc">Precio mas barato</option>
            <option value="desc">Precio mas caro</option>
        </select>

        <input type="submit" value="Filtrar">
        <input type="submit" name="todos" value="Mostrar Todos">
    </form>
   
     <!---PRODUKTU-->
     <?php
    require_once(__DIR__ . '/../../../../php/produktu.php');
    ?>



    
     <!---FOOTER-->
     <?php
    require_once(__DIR__ . '/../../../../php/footer_esp.php');
    ?>
    <?php
    $conn->close();
    ?>
</body>
</html>