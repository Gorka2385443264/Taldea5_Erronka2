<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../../../../../public/Argazkiak/phonix.png">
    <script src="https://kit.fontawesome.com/7f605dc8fe.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../../../../css/informazioa.css">
    <title>Informacion</title>
</head>
<body>
    <div class="oferta">
        <p>¡Oferta!</p>
    </div>
    <a href="https://www.goierrieskola.eus/es/">
        <img class="goierri" src="../../../../../public/Argazkiak/goierri-logo.png" alt="Goierri Logo" href="https://www.goierrieskola.eus/es/">
    </a>

    <!---HEADER-->
    <?php
    require_once(__DIR__ . '/../../../../php/header_esp.php');
    ?>

    <main>
        <article>
            <h2>¡Bienvenidos a Reborn!</h2>
                <p>
                    Creadores: <br>
                    - Gorka Bartolome <br>
                    - Haimar Arizeta <br>
                    - Eneko Benitez <br>
                    <br><br>
                   
Bienvenidos a Reborn, una innovadora empresa que readapta ordenadores y productos informáticos. En un mundo de continua evolución tecnológica, nuestro principal objetivo es reactivar los dispositivos electrónicos, ofrecer soluciones asequibles y fomentar la sostenibilidad en la industria tecnológica.  <br><br>
A través de nuestro compromiso con la calidad, la accesibilidad y la responsabilidad medioambiental, estamos redefiniendo cómo influye la tecnología en nuestras vidas y en el planeta. Únete a nosotros en este apasionante viaje hacia un futuro más inteligente y sostenible.
<br><br>
Elegimos esta ubicación porque Estonia representa un escenario ideal para nuestra empresa. El entorno digital avanzado del país y su gestión empresarial completamente digitalizada son fundamentales para nuestra visión innovadora. La ubicación estratégica en Europa nos brinda un acceso fácil al mercado europeo, lo que nos permitirá expandir nuestras operaciones sin complicaciones.
<br><br>
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2029.1327978583063!2d24.751430199999998!3d59.430859700000006!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4692949f7ae44fe5%3A0x8d0a32860b59f9b5!2sKentmanni%2C%20Tallinn%2C%20Estonia!5e0!3m2!1ses!2ses!4v1698934308789!5m2!1ses!2ses" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
</p>			
        </article>
    </main>
   
 
     <!---FOOTER-->
     <?php
    require_once(__DIR__ . '/../../../../php/footer_esp.php');
    ?>
</body>
</html>
