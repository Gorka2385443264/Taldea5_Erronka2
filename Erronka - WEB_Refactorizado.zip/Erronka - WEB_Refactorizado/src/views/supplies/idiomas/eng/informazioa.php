<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../../../../../public/Argazkiak/phonix.png">
    <script src="https://kit.fontawesome.com/7f605dc8fe.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../../../../css/informazioa.css">
    <title>Suppliers</title>
</head>
<body>
    <div class="oferta">
        <p>¡Offer!</p>
    </div>
    <a href="https://www.goierrieskola.eus/es/">
        <img class="goierri" src="../../../../../public/Argazkiak/goierri-logo.png" alt="Goierri Logo" href="https://www.goierrieskola.eus/es/">
    </a>

     <!---HEADER-->
     <?php
    require_once(__DIR__ . '/../../../../php/header2_eng.php');
    ?>


    <main>
        <article>
            <h2>¡Welcome to Reborn!</h2>
                <p>
                    Creators: <br>
                    - Gorka Bartolome <br>
                    - Haimar Arizeta <br>
                    - Eneko Benitez <br>
                    <br><br>

                    Welcome to Reborn, an innovative company that repurposes computers and IT products. In a world of continuous technological evolution, our main objective is to revive electronic devices, offer affordable solutions and promote sustainability in the technology industry. <br><br>
Through our commitment to quality, accessibility and environmental responsibility, we are redefining how technology influences our lives and the planet. Join us on this exciting journey towards a smarter, more sustainable future.
<br><br>
We chose this location because Estonia represents an ideal setting for our company. The country's advanced digital environment and its fully digitalized business management are fundamental to our innovative vision. The strategic location in Europe gives us easy access to the European market, which will allow us to expand our operations without complications.
<br><br>
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2029.1327978583063!2d24.751430199999998!3d59.430859700000006!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4692949f7ae44fe5%3A0x8d0a32860b59f9b5!2sKentmanni%2C%20Tallinn%2C%20Estonia!5e0!3m2!1ses!2ses!4v1698934308789!5m2!1ses!2ses" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
</p>			
        </article>
    </main>
   
 
    <!---FOOTER-->
    <?php
    require_once(__DIR__ . '../../../../../php/footer.php');
    ?>
</body>
</html>
