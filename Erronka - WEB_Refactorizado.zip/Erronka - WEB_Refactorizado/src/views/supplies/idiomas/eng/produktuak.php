
<!---PRODUKTU-->
<?php
    require_once(__DIR__ . '/../../../../php/produktu_eng.php');
    ?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../../../../../public/Argazkiak/phonix.png">
    <script src="https://kit.fontawesome.com/7f605dc8fe.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../../../../css/produktuak2.css">
    <title>Suppliers</title>
</head>
<body>
    <div class="oferta">
        <p>¡Offer!</p>
    </div>
    <a href="https://www.goierrieskola.eus/es/">
        <img class="goierri" src="../../../../../public/Argazkiak/goierri-logo.png" alt="Goierri Logo" href="https://www.goierrieskola.eus/es/">
    </a>

    <!---HEADER-->
    <?php
    require_once(__DIR__ . '/../../../../php/header2_eng.php');
    ?>
    <center>
        <div class="hornitzailea">
            <p><a href="hornitzailea.php">Do you want to be a supplier?</a></p>
        </div>
    </center><br><br>

    <h2>Products Table</h2>

    <form method="GET">
        <label for="marca">Filter by brand:</label>
        <select name="marca" id="marca">
            <option value="">Select a brand</option>
            <?php foreach ($marcas as $marca) : ?>
                <option value="<?php echo $marca; ?>"><?php echo $marca; ?></option>
            <?php endforeach; ?>
        </select>

        <label for="modelo">Filter by model:</label>
        <select name="modelo" id="modelo">
            <option value="">Select a model</option>
            <?php foreach ($modelos as $modelo) : ?>
                <option value="<?php echo $modelo; ?>"><?php echo $modelo; ?></option>
            <?php endforeach; ?>
        </select>

        <label for="precio">Sort by price:</label>
        <select name="precio" id="precio">
            <option value="asc">Cheaper price</option>
            <option value="desc">More expensive price</option>
        </select>

        <input type="submit" value="Filter">
        <input type="submit" name="todos" value="Show all">
    </form>
   
     <!---PRODUKTU-->
     <?php
    require_once(__DIR__ . '/../../../../php/produktu.php');
    ?>



    
      <!---FOOTER-->
      <?php
    require_once(__DIR__ . '/../../../../php/footer.php');
    ?>    


    <?php
    $conn->close();
    ?>
</body>
</html>