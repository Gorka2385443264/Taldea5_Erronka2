<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../../../../../public/Argazkiak/phonix.png">
    <script src="https://kit.fontawesome.com/7f605dc8fe.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../../../../css/hornitzailea.css">
    <title>Suppliers</title>
</head>
<body>
    <div class="oferta">
        <p>¡Offer!</p>
    </div>
    <a href="https://www.goierrieskola.eus/es/">
        <img class="goierri" src="../../../../../public/Argazkiak/goierri-logo.png" alt="Goierri Logo" href="https://www.goierrieskola.eus/es/">
    </a>

     <!---HEADER-->
     <?php
    require_once(__DIR__ . '/../../../../php/header2_eng.php');
    ?>

    <div class="form">
        <form method="POST">
            <h1> - Fill the form -</h1><br>
            <label for="empresa">Company name:</label>
            <input type="text" id="empresa" name="empresa" placeholder="Put the name of the company here" required><br>

            <label for="material">Material:</label>
            <input type="text" id="material" name="material" placeholder="Put your material here" required><br>

            <label for="webgunea">Company website:</label>
            <input type="text" name="webgunea" id="webgunea" placeholder="Put the website here"><br>

            <label for="kontua">Current account:</label>
            <input type="text" name="kontua" id="kontua" placeholder="Put your checking account here"><br>

            <label for="telefono_contacto">Telephone contact:</label>
            <input type="text" name="telefono_contacto" id="telefono_contacto" placeholder="Put your phone here"><br>

            <label for="gmail">Gmail:</label>
            <input type="email" id="gmail" name="gmail" placeholder="Put your email here" required><br>

            <label for="gehigarriak">Extras:</label>
            <textarea name="gehigarriak" cols="60" rows="10"></textarea><br>

            <div class="botones">
                <input type="submit" class="enviar" value="Send">
                <input type="reset" class="enviar" value="Restart">
            </div>
        </form>
    </div>

    <!---HORNITZAILE_INFO-->
    <?php
    require_once(__DIR__ . '/../../../../php/hornitzaile_eng.php');
    ?>
    
             <div class="ir_a_comprar">
                <a href="../../../supplies/idiomas/eng/produktuak.php">Go shopping</a>
             </div>

     <!---FOOTER-->
     <?php
    require_once(__DIR__ . '/../../../../php/footer.php');
    ?>
</body>
</html>
