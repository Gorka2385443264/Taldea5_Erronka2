<header>
    <!--HEADER ENG-->
        <div class="container__menu">
            <!-- la barra -->
            <div class="menu">	
                <nav>
                    <ul>
                        <li><a href="#" id="selected"></a></li>
                        <li><a href="../../supplies/idiomas/eng/informazioa.php" id="informazioa">Information</a></li>	
                        <li><a href="../../supplies/idiomas/eng/produktuak.php">Products</a></li>		
                        <li><a href="#">Languages</a>
                            <ul>
                                <li><a href="../esp/index.php">Spanish</a></li>
                                <li><a href="../eusk/index.php">Baskque</a></li>
                            </ul>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>