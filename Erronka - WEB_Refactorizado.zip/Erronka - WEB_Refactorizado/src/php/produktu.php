<?php
    // Este bloque PHP debería ubicarse donde deseas mostrar los resultados.
    if ($_SERVER["REQUEST_METHOD"] == "GET") {
        if (isset($result) && $result->num_rows > 0) {
            echo '<div class="noticias-container">';
            $counter = 0;

            while ($row = $result->fetch_assoc()) {
                if ($counter % 4 == 0) {
                    echo '<div class="noticias-row">';
                }

                echo '<div class="noticias">';
                echo '<div class="imagen-noticia"><img src="' . $row["imagenes"] . '" alt="Imagen del producto"></div>';
                echo '<div class="contenido-noticia">';
                echo '<h2>' . $row["Produktua"] . '</h2><br>';
                echo '<h4>Marca:  ' . $row["Marca"] . '</h4>';
                echo '<h4>Precio:  ' . $row["Prezioa"] . ' €</h4><br>';
                echo '<h5 class="texto-cortado">Valoración: ' . $row["Iritzia"] . ' /5 <i class="fa fa-star"></i></h5>';
                echo '</div>';
                echo '</div>';

                $counter++;

                if ($counter % 4 == 0) {
                    echo '</div>';
                }
            }
            echo '</div>';
        } else {
            echo 'No se encontraron productos con los filtros seleccionados.';
        }
    }
    ?>