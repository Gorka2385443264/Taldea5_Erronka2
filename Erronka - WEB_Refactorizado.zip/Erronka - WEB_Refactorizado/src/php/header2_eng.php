<!-- header.php -->
<?php
$rootPath = $_SERVER['DOCUMENT_ROOT'];
?>

<header>
    <div class="container__menu">
        <!-- la barra -->
        <div class="menu">    
            <nav>
                <ul>
                    <li><a href="../../../Mainpage/eng/index.php" id="selected"></a></li>
                    <li><a href="informazioa.php" id="informazioa">Information</a></li>
                    <li><a href="produktuak.php">Products</a></li>
                    <li><a href="#">Languages</a>
                        <ul>
                            <li><a href="../../esp/index.php">Spanish</a></li>
                            <li><a href="../../eusk/index.php">Baskque</a></li>
                        </ul>
                    </li>
                </ul>
            </nav>
        </div>
    </div>
</header>