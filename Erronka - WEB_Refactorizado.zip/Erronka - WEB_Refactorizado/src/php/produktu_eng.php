<?php
$servername = "localhost";
$username = "root";
$password = "1WMG2023";
$dbname = "reborn";

// Crear la conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Consulta SQL por defecto para seleccionar todos los productos
$sql = "SELECT * FROM reborn.biltegia";

// Verificar si se han enviado parámetros GET para filtrar
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    if (isset($_GET['marca']) && !empty($_GET['marca'])) {
        $marca = $_GET['marca'];
        $sql .= " WHERE Marca = '$marca'";
    }

    if (isset($_GET['modelo']) && !empty($_GET['modelo'])) {
        $modelo = $_GET['modelo'];
        // Añadir la condición WHERE si no se ha añadido previamente
        $sql .= (strpos($sql, 'WHERE') !== false) ? " AND Produktua = '$modelo'" : " WHERE Produktua = '$modelo'";
    }

    if (isset($_GET['precio']) && !empty($_GET['precio'])) {
        $orden = ($_GET['precio'] == 'asc') ? 'asc' : 'desc';
        // Agregar la cláusula ORDER BY solo si no existe en la consulta
        $sql .= (strpos($sql, 'ORDER BY') !== false) ? " Prezioa $orden" : " ORDER BY Prezioa $orden";
    }
}

// Ejecutar la consulta SQL
$result = $conn->query($sql);

// Obtener las marcas
$sql_marcas = "SELECT DISTINCT Marca FROM reborn.biltegia";
$result_marcas = $conn->query($sql_marcas);
$marcas = [];

if ($result_marcas->num_rows > 0) {
    while ($row = $result_marcas->fetch_assoc()) {
        $marcas[] = $row['Marca'];
    }
}

// Obtener los modelos
$sql_modelos = "SELECT DISTINCT Produktua FROM reborn.biltegia";
$result_modelos = $conn->query($sql_modelos);
$modelos = [];

if ($result_modelos->num_rows > 0) {
    while ($row = $result_modelos->fetch_assoc()) {
        $modelos[] = $row['Produktua'];
    }
}
?>