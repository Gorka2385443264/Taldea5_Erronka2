<?php
    
$servername = "localhost:3306";
$username = "root";
$password = "1WMG2023";
$dbname = "reborn";

// Crear la conexión
$conexion = new mysqli($servername, $username, $password, $dbname);

// Revisar la conexión
if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
}

if (isset($_POST['empresa']) && isset($_POST['material']) && isset($_POST['webgunea']) && isset($_POST['kontua']) && isset($_POST['telefono_contacto']) && isset($_POST['gmail']) && isset($_POST['gehigarriak'])) {

    $empresa = $_POST['empresa'];
    $material = $_POST['material'];
    $webgunea = $_POST['webgunea'];
    $kontua = $_POST['kontua'];
    $telefono = $_POST['telefono_contacto'];
    $gmail = $_POST['gmail'];
    $gehigarriak = $_POST['gehigarriak'];
    $id = NULL;

    // Corregir la sintaxis de la consulta SQL y agregar comillas a los valores de cadena
    $sqlInsertar = "INSERT INTO reborn.hornitzailea (ID, Enpresa, Materiala, Enpresaren_webgunea, Kontu_zenbakia_ES00_0000_0000_0000_0000_0000, Telefono_zenbakia, Enpresaren_gmail_helbidea, Gehigarriak) VALUES (NULL, '$empresa', '$material', '$webgunea', '$kontua', '$telefono', '$gmail', '$gehigarriak')";

    $resultado = $conexion->query($sqlInsertar);
}
?>