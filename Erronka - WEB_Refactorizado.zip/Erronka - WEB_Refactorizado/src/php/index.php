<?php
$servername = "localhost:3306";
$username = "root";
$password = "1WMG2023";
$dbname = "reborn";

$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$sql = "SELECT * FROM reborn.noticias";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['ordenar_fecha'])) {
        $sql .= " ORDER BY Fecha {$_POST['orden']}";
    }

    if (isset($_POST['buscar_por_fecha'])) {
        $fecha_ingresada_por_el_usuario = $_POST['fecha_ingresada'];
        $sql = "SELECT * FROM reborn.noticias WHERE fecha <= '$fecha_ingresada_por_el_usuario' ORDER BY fecha ASC LIMIT 1";
    } elseif (isset($_POST['buscar_mas_vieja'])) {
        $fecha_ingresada_por_el_usuario = $_POST['fecha_ingresada_vieja'];
        $sql = "SELECT * FROM reborn.noticias WHERE fecha <= '$fecha_ingresada_por_el_usuario'";
    } elseif (isset($_POST['buscar_mas_nueva'])) {
        $fecha_ingresada_por_el_usuario = $_POST['fecha_ingresada_nueva'];
        $sql = "SELECT * FROM reborn.noticias WHERE fecha >= '$fecha_ingresada_por_el_usuario'";
    } elseif (isset($_POST['buscar_entre_fechas'])) {
        $fecha_inicial = $_POST['fecha_inicial'];
        $fecha_final = $_POST['fecha_final'];
        $sql = "SELECT * FROM reborn.noticias WHERE fecha BETWEEN '$fecha_inicial' AND '$fecha_final'";
    } elseif (isset($_POST['ver_todos'])) {
        $sql = "SELECT * FROM reborn.noticias";
    }
}

$result = $conn->query($sql);
?>