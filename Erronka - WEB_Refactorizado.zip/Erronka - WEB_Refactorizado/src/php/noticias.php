 <?php
if ($result->num_rows > 0) {
    echo '<div class="noticias-container">';
    $counter = 0;

    while ($row = $result->fetch_assoc()) {
        if ($counter % 3 == 0) {
            echo '<div class="noticias-row">';
        }

        echo '<div class="noticias">';
        echo '<div class="imagen-noticia"><img src="' . $row["Imagen"] . '" alt="Imagen del producto"></div>';
        echo '<div class="contenido-noticia">';
        echo '<h2>' . $row["Fecha"] . '</h2>';
        echo '<h3>' . $row["Izenburua"] . '</h3><br>';
        echo '<p class="texto-cortado">' . $row["Textua"] . '</p>';
        echo '</div>'; // Cierre de div para el contenido de la noticia
        echo '</div>'; // Cierre de div para la noticia

        $counter++;

        if ($counter % 3 == 0) {
            echo '</div>'; // Cierre de la fila después de 3 noticias
        }
    }

    echo '</div>'; // Cierre del contenedor principal
} else {
    echo 'No se encontraron las noticias, en las fechas indicadas.';
}
?>